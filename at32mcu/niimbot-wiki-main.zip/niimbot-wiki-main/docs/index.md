# Welcome

!!! warning

    This wiki is an independent, non-profit resource created for educational and research purposes only.
    It is not affiliated with, endorsed by, or sponsored by NIIMBOT.
    All information is provided "as is" without warranty of any kind.
    Use of this material is at your own risk.
    Users are responsible for ensuring that their activities comply with applicable laws, licenses, and terms of service.

This wiki contains information about the design and operation of NIIMBOT label printers. You are welcome to contribute.

This wiki is related to the [niimbluelib](https://github.com/MultiMote/niimbluelib) project.

![printers](printers.jpg)
