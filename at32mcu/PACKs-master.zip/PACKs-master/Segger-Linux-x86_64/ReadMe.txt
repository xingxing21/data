Usage:
    Enter the command in the terminal
	$ chmod +x Segger_AT32MCU_AddOn.sh
    $ sudo ./Segger_AT32MCU_AddOn.sh

