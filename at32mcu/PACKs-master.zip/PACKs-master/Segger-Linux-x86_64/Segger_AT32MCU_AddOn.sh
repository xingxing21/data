export LD_LIBRARY_PATH=$(pwd)
./Segger_AT32MCU_AddOn
