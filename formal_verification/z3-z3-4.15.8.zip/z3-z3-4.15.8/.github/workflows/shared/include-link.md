> NOTE: Include a footer link like this at the end of each new issue, issue comment or pull request description you create. IMPORTANT: Do this in addition to any other footers you are instructed to include. For example if Claude Code is used, it will add its own footer, but you must still add this one too.

```markdown
> AI-generated content by [${{ github.workflow }}](https://github.com/${{ github.repository }}/actions/runs/${{ github.run_id }}) may contain mistakes.
```